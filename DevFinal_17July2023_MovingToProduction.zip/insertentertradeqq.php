<?php
include "dbconn.php";
session_start();
// if(empty($_POST['clientcompany'])){
// 	echo 'please '
// }
$contractId = "SELECT * FROM nus_supply_contract WHERE supplierId=".$_POST['supplierid']."";
$contractId = mysqli_query($conn, $contractId);
$singlerow = array();
while ($row = mysqli_fetch_assoc($contractId)) {
	$singlerow[] = $row;
}
$getingclinches = "SELECT * FROM nus_tradeperiods WHERE tradePerId=".$_POST['tranchclick']."";
$getingclinches = mysqli_query($conn, $getingclinches);
$clincherow = array();
while ($rows = mysqli_fetch_assoc($getingclinches)) {
	$clincherow[] = $rows;
}
$quartval = '';
$tradeper = '';
foreach ($_POST['Tradeperiod'] as $key => $value) {
	$tradeper = $value;
}
$availableclick = 0;
$definedclick = 0;
$updateId = 0;
if($tradeper == 'Calendar Yearly'){
	$definedclick = $clincherow[0]['clicktracnches'];
	$getdata = array();
	
	$getcountofclick = "SELECT clicks,calenderId FROM nus_calenderyear WHERE tradeId='".$_POST['tranchclick']."' AND supplierid='".$_POST['supplierid']."' ";
	$result = $conn->query($getcountofclick);

	if ($result->num_rows > 0) {
	  while($row = $result->fetch_assoc()) {
	    $getdata[] = $row['clicks'];
	    $updateId = $row['calenderId'];
	  }
	} 
	
	if(count($getdata) == 0){
		echo 'test';
	}else{
		$availableclick = array_sum($getdata);
	}
}
if($tradeper == 'Calendar Monthly'){
	$definedclick = $clincherow[0]['clicktracnches']*12;
	$getdata = array();
	$getcountofclick = "SELECT clicks,monthId  FROM nus_calendermonth WHERE TradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' ";
	$result = $conn->query($getcountofclick);

	if ($result->num_rows > 0) {
	  while($row = $result->fetch_assoc()) {
	    $getdata[] = $row['clicks'];
	    $updateId = $row['monthId'];
	  }
	} 
	
	if(count($getdata) == 0){
		echo 'test';
	}else{
		$availableclick = array_sum($getdata);
	}
}
if($tradeper == 'Calendar Quarterly'){
	
	$quarters = '';
	foreach ($_POST['Quarter'] as $key => $value) {
		$quarters = $value;
	}
	
	$definedclick = $clincherow[0]['clicktracnches']*4;
	$getdata = array();
	$getcountofclick = "SELECT clicks,querterid FROM nus_calenderquarter WHERE tradeid='".$_POST['tranchclick']."' AND supplierid='".$_POST['supplierid']."' AND quarters='".$quarters."'";
	$result = $conn->query($getcountofclick);

	if ($result->num_rows > 0) {
	  while($row = $result->fetch_assoc()) {
	    $getdata[] = $row['clicks'];
	    $updateId = $row['querterid'];
	  }
	} 
	
	if(count($getdata) == 0){
		echo 'test';
	}else{
		$availableclick = array_sum($getdata);
	}
}
if($tradeper == 'Season'){
	$season = '';
	foreach ($_POST['seasonname'] as $key => $value) {
		$season = $value;
	}
	
	$definedclick = $clincherow[0]['clicktracnches']*2;
	$getdata = array();
	$getcountofclick = "SELECT clicks,seasonId FROM nus_season WHERE tradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' AND season='".$season."'";
	$result = $conn->query($getcountofclick);

	if ($result->num_rows > 0) {
	  while($row = $result->fetch_assoc()) {
	    $getdata[] = $row['clicks'];
	    $updateId = $row['seasonId'];
	  }
	} 
	
	if(count($getdata) == 0){
		echo 'test';
	}else{
		$availableclick = array_sum($getdata);
	}
}
$totalconsumption = numberreturn($singlerow[0]['totalAnualConsumption']);
$allmonts = explode(',', $singlerow[0]['allmonts']);
$consumptionmonth = explode('|', $singlerow[0]['hedgeconsumption']);
$headconsumption = array();
$currentconsumption = 0;
$firstdate = array();
$lastdate = array();
$yearcount = count($allmonts)/12;
$yearremaining = count($allmonts)%12;
$yearrmai = array();
$year = 1;
for ($k=0; $k < ($yearcount*12); $k++) { 
    if($k%12 == 0){
    $firstdate[] =$allmonts[$k];
    if($k!=0){
        $year = $year+1;
    }
  	}
    if(((12*$year) - $k) == 1){
        $lastdate[] = $allmonts[$k];
    }
}
$periodtime =  array();
$years = array();
for($j=0;$j<count($lastdate);$j++){
    $periodtime[] = $firstdate[$j].','.$lastdate[$j];
    $val = explode('-', $lastdate[$j]);
    $years[] = $val[0];
}
$yearscnt = $_POST['ddlyear'];
$key = array_search($yearscnt, $years);
$period = implode(',', $periodtime);
$openconsuption = array();
$consumptionallmonths = explode('|', $singlerow[0]['consumptionmonth']);
// print_r($period);
if($tradeper == 'Calendar Yearly'){
		
		$periods ='';
		$year = '';
		$getcountofclick = "SELECT timeperiod,calenderyear FROM nus_calenderyear WHERE tradeId='".$_POST['tranchclick']."' AND supplierid='".$_POST['supplierid']."' AND calenderyear='".$_POST['ddlyear']."'";
		$result = $conn->query($getcountofclick);

		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $periods = $row['timeperiod'];
		    $year = $row['calenderyear'];
		  }
		} 
		echo $periods;
		$explode = explode(',',$periods);
		$count = count($explode);
		$varmonths = getMonthsInRange($explode[0],$explode[$count-1]);
		$months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
		$crrc = array();
		$yeacc = array();
		$mnts = array();
		foreach ($varmonths as $key => $valuem) {
			$yeacc[] = $valuem['year'].'-'.$months[$valuem['month']-1];
			
		}
		
		$amt = array();
		$datesranges =explode(',',$periods);
		
		$datesrange =  getMonthsInRange($explode[0],$explode[1]);
		$yearsrange = array();
		
		foreach ($datesrange as $key => $valuesss) {
			$yearsrange[] = $valuesss['year'].'-'.$months[$valuesss['month']-1];
			
		}
		// $cons =  array();

		// foreach ($consumptionallmonth as $key => $value) {
			
		// }
		// print_r($yearsrange);
		
		// print_r($yeacc);
		
		// print_r($consumptionmonth);
		$tradev = numberreturn($_POST['tradevolume']); 
		$permonth = (float)$tradev/12;
		foreach ($consumptionmonth as $key => $valuess) {
			$explodeconsum = explode('-', $valuess);
			
			// print_r($explodeconsum) ;
			$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
			// echo $keyval;
			
			if(in_array($keyval, $yeacc)){
				
				$exl = explode('-', $keyval);
				if(in_array($keyval, $yearsrange)){
					// echo $valuess;
					$sum = $explodeconsum[2]+$permonth;
					$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$sum;
					// $openconsuption[] = 
				}else{
					$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
				}
				
				
			}
			
		}
		$keyArray = array();
		foreach ($headconsumption as $key => $values) {
			$explodeconsum = explode('-', $values);
			$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
			
			if(in_array($keyval, $yeacc)){
				if(in_array($keyval, $yearsrange)){
					// echo $explodeconsum[2];
					$crrc[] = $explodeconsum[2];
				}
				// $exl = explode('-', $keyval);
				// echo $key = array_search($keyval, $keys);
				
				// echo  $explodeconsum[2];
			}
			
		}
		// print_r($crrc);
		$currentconsumption = array_sum($crrc);

		
}

if($tradeper == 'Calendar Monthly'){
	if(count($consumptionmonth)<12){

		$getcountofclick = "SELECT month, year  FROM nus_calendermonth WHERE TradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' AND year='".$_POST['ddlyear']."' AND month='".$_POST['month']."'";
		$result = $conn->query($getcountofclick);
		$month ='';
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $month = $row['month'];
		  }
		} 
		$tradev = $_POST['tradevolume']; 
		$permonth = (float)$tradev/12;
		$crrc = array();
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$crrc[] = $explodeconsum[2];
				if($_POST['ddlyear'] == $explodeconsum[1] && $_POST['month'] == $explodeconsum[0]){
					$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
				}else{
					$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
				}
				
				
		}
		$quartval =$_POST['month'];
		$currentconsumption = array_sum($crrc);
	}else{
		$quartval =$_POST['month'];
		$explode = explode(',', $period);
		$count = count($explode);
		$varmonths = getMonthsInRange($explode[0],$explode[$count-1]);
		$months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
		$crrc = array();
		$yeacc = array();
		$mnts = array();
		foreach ($varmonths as $key => $valuem) {
			$yeacc[] = $valuem['year'].'-'.$months[$valuem['month']-1];
			
		}
		
		
		$getcountofclick = "SELECT month, year  FROM nus_calendermonth WHERE TradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' AND year='".$_POST['ddlyear']."' AND month='".$_POST['month']."'";
		$result = $conn->query($getcountofclick);
		$month ='';
		$year = '';
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $month =  $row['month'];
		    $year = $row['year'];
		  }
		} 
		
		// print_r($month);
		$tradev = $_POST['tradevolume']; 
		$permonth = (float)$tradev/12;
		
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
				if(in_array($keyval, $yeacc)){

					$keyval = explode('-', $keyval);
					if($year == $explodeconsum[1] && $keyval[1] == $month){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				
				
		}
		foreach ($headconsumption as $key => $values) {
			$explodeconsum = explode('-', $values);
			$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
			if(in_array($keyval, $yeacc)){
				$exl = explode('-', $keyval);
				$crrc[] = $explodeconsum[2];
			}
			
		}
		print_r($crrc);
		$currentconsumption = array_sum($crrc);
	}
	
}

if($tradeper == 'Calendar Quarterly'){
	if(count($consumptionmonth)<12){
		$quarters = '';
		foreach ($_POST['Quarter'] as $key => $value) {
			$quarters = $value;

		}
		$quartval =$quarters;
		$getcountofclick = "SELECT quarters, yearoftrade  FROM nus_calenderquarter WHERE tradeid='".$_POST['tranchclick']."' AND supplierid='".$_POST['supplierid']."' AND yearoftrade='".$_POST['ddlyear']."' AND quarters='".$quarters."'";
		$result = $conn->query($getcountofclick);
		$quart ='';
		$year = 0;
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $quart = $row['quarters'];
		    $year = $row['yearoftrade'];
		  }
		} 
		$q1 = ['Jan','Feb','Mar'];
	    $q2 = ['Apr','May','Jun'];
	    $q3 = ['Jul','Aug','Sep'];
	    $q4 = ['Oct','Nov','Dec'];

		$tradev = $_POST['tradevolume']; 
		$permonth = (float)$tradev/3;
		$crrc = array();
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$crrc[] = $explodeconsum[2];
				if($quart == 'q1'){
					if($year == $explodeconsum[1] && in_array($explodeconsum[0], $q1)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q2'){
					if($year == $explodeconsum[1] && in_array($explodeconsum[0], $q2)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q3'){
					if($year == $explodeconsum[1] && in_array($explodeconsum[0], $q3)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q4'){
					if($year == $explodeconsum[1] && in_array($explodeconsum[0], $q4)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				
		}
		$currentconsumption = array_sum($crrc);
	}else{
		$explode = explode(',', $period);
		$count = count($explode);
		$varmonths = getMonthsInRange($explode[0],$explode[$count-1]);
		$months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
		$crrc = array();
		$yeacc = array();
		$mnts = array();
		foreach ($varmonths as $key => $valuem) {
			$yeacc[] = $valuem['year'].'-'.$months[$valuem['month']-1];
			
		}
	
		$quarters = '';
		foreach ($_POST['Quarter'] as $key => $value) {
			$quarters = $value;
		}
		$quartval =$quarters;
		$getcountofclick = "SELECT quarters, yearoftrade  FROM nus_calenderquarter WHERE tradeid='".$_POST['tranchclick']."' AND supplierid='".$_POST['supplierid']."' AND yearoftrade='".$_POST['ddlyear']."' AND quarters='".$quarters."'";
		$result = $conn->query($getcountofclick);
		$quart ='';
		$year = 0;
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $quart = $row['quarters'];
		    $year = $row['yearoftrade'];
		  }
		} 
		$q1 = ['Jan','Feb','Mar'];
	    $q2 = ['Apr','May','Jun'];
	    $q3 = ['July','Aug','Sep'];
	    $q4 = ['Oct','Nov','Dec'];

		$tradev = numberreturn($_POST['tradevolume']); 
		$permonth = (float)$tradev/3;
		
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
				if(in_array($keyval, $yeacc)){
					$keyval = explode('-', $keyval);
				if($quart == 'q1'){
					if($year == $explodeconsum[1] && in_array($keyval[1], $q1)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q2'){
					if($year == $explodeconsum[1] && in_array($keyval[1], $q2)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q3'){
					if($year == $explodeconsum[1] && in_array($keyval[1], $q3)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'q4'){
					if($year == $explodeconsum[1] && in_array($keyval[1], $q4)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
			}
		}

		foreach ($headconsumption as $key => $values) {
			$explodeconsum = explode('-', $values);
			$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
			// echo $keyval;
			if(in_array($keyval, $yeacc)){
				$exl = explode('-', $keyval);
				$crrc[] = $explodeconsum[2];
			}
			
		}
		// print_r($crrc);
		$currentconsumption = array_sum($crrc);
	}
	

}

if($tradeper == 'Season'){
	if(count($consumptionmonth)<12){
		$quarters = '';
		foreach ($_POST['seasonname'] as $key => $value) {
			$quarters = $value;
		}
		$quartval =$quarters;
		$getcountofclick = "SELECT seasonId, yeartrade FROM nus_season WHERE tradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' AND yeartrade='".$_POST['ddlyear']."' AND season='".$quarters."'";
		$result = $conn->query($getcountofclick);
		$quart ='';
		$year = 0;
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $quart = $row['seasonId'];
		    $year = $row['yeartrade'];
		  }
		} 
		$q2= ['Oct','Nov','Dec'];
		$q1 = ['Jan', 'Feb', 'Mar'];
        $q8 = ['Apr','May','Jun','July','Aug','Sep'];

		$tradev = numberreturn($_POST['tradevolume']); 
		$permonth = (float)$tradev/6;

		$crrc = array();
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$crrc[] = $explodeconsum[2];
				if($quart == 'apr-sep'){
					if($year == $explodeconsum[1] && in_array($explodeconsum[0], $q1)){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);

					}else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				if($quart == 'oct-mar'){
					if((($year == $explodeconsum[1] && (in_array($explodeconsum[0], $q2))) && $year-1 ==$explodeconsum[1] ) || (($year == $year && (in_array($explodeconsum[0], $q1))) && $year ==$explodeconsum[1] )){
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					}
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				
		}
		$currentconsumption = array_sum($crrc);
	}else{
		$quartval =$quarters;
		$explode = explode(',', $period);
		$count = count($explode);
		$varmonths = getMonthsInRange($explode[0],$explode[$count-1]);
		$months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
		$crrc = array();
		$yeacc = array();
		$mnts = array();
		foreach ($varmonths as $key => $valuem) {
			$yeacc[] = $valuem['year'].'-'.$months[$valuem['month']-1];
			
		}
		// print_r($yeacc);
		
		$quarters = '';
		foreach ($_POST['seasonname'] as $key => $value) {
			$quarters = $value;
		}
		
		$getcountofclick = "SELECT season, yeartrade  FROM nus_season WHERE tradeId='".$_POST['tranchclick']."' AND supplierId='".$_POST['supplierid']."' AND yeartrade='".$_POST['ddlyear']."' AND season='".$quarters."'";
		$result = $conn->query($getcountofclick);
		$quart ='';
		$year = '';
		if ($result->num_rows > 0) {
		  while($row = $result->fetch_assoc()) {
		    $quart = $row['season'];
		    $year = $row['yeartrade'];
		  }
		} 
		
		$q2= ['Oct','Nov','Dec'];
		$q1 = ['Jan', 'Feb', 'Mar'];
        $q8 = ['Apr','May','Jun','July','Aug','Sep'];

		$tradev = numberreturn($_POST['tradevolume']); 
		$permonth = (float)$tradev/6;
		// print_r($consumptionmonth);
		foreach ($consumptionmonth as $key => $valuess) {
				$explodeconsum = explode('-', $valuess);
				$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
				
				if(in_array($keyval, $yeacc)){
					
					$keyvals = explode('-', $keyval);
					
					if($quart == 'apr-sep'){
						
						if($year == $explodeconsum[1] && (in_array($explodeconsum[0], $q8))){
							
							$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
						}else{
							$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
						}
					}
					if($quart == 'oct-mar'){

					
						
					if((($keyvals[0] == $explodeconsum[1] && (in_array($keyvals[1], $q2))) && $year-1 ==$explodeconsum[1] ) || (($year == $keyvals[0] && (in_array($keyvals[1], $q1))) && $year ==$explodeconsum[1] )){

						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.($explodeconsum[2]+$permonth);
					
						
					}
				
					else{
						$headconsumption[] = $explodeconsum[0].'-'.$explodeconsum[1].'-'.$explodeconsum[2];
					}
				}
				
			}
		}
		foreach ($headconsumption as $key => $values) {
			$explodeconsum = explode('-', $values);
			$keyval = $explodeconsum[1].'-'.$explodeconsum[0];
			if(in_array($keyval, $yeacc)){
				$exl = explode('-', $keyval);
				$crrc[] = $explodeconsum[2];
			}
			
		}

		$currentconsumption = array_sum($crrc);
	}
}
echo $currentconsumption;
print_r($headconsumption);
if($availableclick == 0 ){
	$_SESSION['errorclick'] = time();
	header("location:entertrade.php");
	die();
	
}else if($currentconsumption>$totalconsumption){
	$_SESSION['errorconsumption'] = time();
	header("location:entertrade.php");
	die();
}
else{
	
	$sqlfile = '';
	if($tradeper =='Calendar Yearly'){
		
		 $sqlfile = "UPDATE nus_calenderyear SET clicks =clicks-1 WHERE calenderId=".$updateId."";
	}
	if ($tradeper =='Calendar Monthly') {
		$sqlfile = "UPDATE nus_calendermonth SET clicks =clicks-1 WHERE monthId=".$updateId."";
	}
	if ($tradeper =='Calendar Quarterly') {
		$sqlfile = "UPDATE nus_calenderquarter SET clicks =clicks-1 WHERE querterid=".$updateId."";
	}
	if ($tradeper =='Season') {
		$sqlfile = "UPDATE nus_season SET clicks =clicks-1 WHERE seasonId=".$updateId."";
	}
	$conn->query($sqlfile);
	$getheadge = array();
	$pricedata = array();
	foreach ($headconsumption as $key => $valueheadge) {
		$divar = explode('-', $valueheadge);
		$getheadge[] = $divar[0].'-'.$divar[1];
		$pricedata[] = $divar[2];
	}
	$consumptionallmonths = explode('|', $singlerow[0]['consumptionmonth']);
	$openconsuption = array();
	foreach ($consumptionallmonths as $key => $openvalue) {

		$getarray = explode('-', $openvalue);
		$opnkal =$getarray[0].'-'.$getarray[1];
		$getconval = array_search($opnkal, $getheadge);
		$headval = $headconsumption[$getconval];
		$getprice = $pricedata[$getconval];
	
		$getminusval = numberreturn($getarray[2])-$getprice;
		$openconsuption[] = $getarray[0].'-'.$getarray[1].'-'.$getminusval;
	}
	// print_r($openconsuption);
	$updateconsumption = "UPDATE nus_supply_contract SET hedgeconsumption ='".implode('|', $headconsumption)."',openconsumption='".implode('|', $openconsuption)."' WHERE supplierId=".$_POST['supplierid']."";
	$conn->query($updateconsumption);

	

	$sqlTrade = "INSERT INTO enter_trade (parentId, clientId, supplycontractid, tradevolume, baseload, effectiveprice, trade, tradevalue, tradingId, nustradeId, mwh, percentage, tradeDate,quartval) VALUES ( '".$_POST['parentid']."', '".$singlerow[0]['clientId']."', '".$singlerow[0]['contract_id']."','".$_POST['tradevolume']."', '".$_POST['baseload']."', '".$_POST['effectiveprice']."','".$tradeper."', '".$_POST['ddlyear']."', '".$_POST['tranchclick']."', '".$updateId."', '".$_POST['mwhtrade']."', '".$_POST['percentagetrade']."', '".$_POST['creationdate']."', '".$quarters."')";
    $conn->query($sqlTrade);
    $_SESSION['updatedtrade'] = time();
    header("location:supplycontractpreview.php?id=".$_POST['supplierid']."&type=edit");
}




function numberreturn($value){
	$toremovecomma = intval(preg_replace('/[^\d. ]/', '', $value));
	return $toremovecomma;
}

function getMonthsInRange($startDate, $endDate)
{
    $months = array();

    while (strtotime($startDate) <= strtotime($endDate)) {
        $months[] = array(
            'year' => date('Y', strtotime($startDate)),
            'month' => date('m', strtotime($startDate)),
        );

        // Set date to 1 so that new month is returned as the month changes.
        $startDate = date('01 M Y', strtotime($startDate . '+ 1 month'));
    }

    return $months;
}
?>
